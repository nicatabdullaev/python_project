from tkinter import *
from tkinter import messagebox
def customers_frame():
    frameProducts.place_forget()
    frameMakeSell.place_forget()
    frameInfo.place_forget()
    frameCustomer.place(x=100, y=10)

def Products_frame():
    frameCustomer.place_forget()
    frameMakeSell.place_forget()
    frameProducts.place(x=100, y=10)
    frameInfo.place_forget()

def MakeSell_frame():
    frameMakeSell.place(x=110,y=10)
    frameCustomer.place_forget()
    frameProducts.place_forget()
    frameInfo.place_forget()

def Info_frame():
    frameMakeSell.place_forget()
    frameCustomer.place_forget()
    frameProducts.place_forget()
    frameInfo.place(x=110,y=10)

#----------BACKEND---------------

total_money = []

class Customer:
    def __init__(self, ad, soyad, yas, telefon_nom):
        self.name = ad
        self.surname = soyad
        self.age = yas
        self.phone = telefon_nom
        self.bought_list = []

    def __str__(self):
        my_str = 'Musterini adi: ' + self.name + \
                 '\nMusterini soyadi: ' + self.surname + \
                 '\nMusterinin yasi: ' + str(self.age) + \
                 '\nMusterinin telefon nomresi: ' + self.phone
        return my_str


c1 = Customer('Nicat  ', 'Abdullayev  ', 12, '+004553427544')
all_customers_list = []


class Product:
    def __init__(self, ad_mehsul, qiymet_mehsul, say_mehsul):
        self.name_product = ad_mehsul
        self.price_product = qiymet_mehsul
        self.count = say_mehsul

    def __str__(self):
        my_str = 'Mehsulun adi:   '+self.name_product + '  \nMehsulun Qiymeti:   '+str(self.price_product) + '  \nMehsulun sayi:   '+ str(self.count)
        return my_str


p1 = Product('Kostyum_1', 160, 120)
all_product_list = []

class DailyTrade:
    def __init__(self,trade,date):
        self.trade = trade
        self.date = date

    def __str__(self):
        my_str = 'Gunluk Alver:  '+str(self.trade)+'\nTarix:  '+self.date
        return my_str

def add_new_trade(trade,date):
    temp_trade = DailyTrade(trade,date)
    all_trade_list.append(temp_trade)
    trade_list_box.insert(END,all_trade_list[-1])

def add_new_trade_btn():
    total=0
    n=0
    daily_trade = daily_price_calcul_entry.get()
    date_ent = date_entry.get()
    total_money.append(int(daily_trade))
    while n<len(total_money):
        total+=total_money[n]
        n+=1

    total_money_lbl.config(text=total)
    # print(total_money)




    if daily_trade !='' and date_ent !='' :
        add_new_trade(daily_trade, date_ent)
    else:
        messagebox.showwarning('Xeta','Xanalari doldurun')
all_trade_list=[]




def add_new_product(mehsul_ad, mehsulun_qiymeti, say_mehsul):
    temp_product = Product(mehsul_ad, int(mehsulun_qiymeti), say_mehsul)
    all_product_list.append(temp_product)
    # for elem in all_product_list:
    product_list_box.insert(END,all_product_list[-1])
    product_list_box_product.insert(END,all_product_list[-1])



def add_new_product_btn():
    product_name = p_entry.get()
    product_price = p_price_entry.get()
    product_count = p_count_entry.get()
    if product_name !='' and product_price !='' and product_count!='':
        add_new_product(product_name, int(product_price), product_count)
    else:
        messagebox.showwarning('Xeta','Xanalari doldurun')



def add_new_customers(ad, soyad, yas, telefon_nom):
    temp_customer = Customer(ad, soyad, yas, telefon_nom)
    all_customers_list.append(temp_customer)
    person_list_box.insert(END, all_customers_list[-1])
    person_list_box_customer.insert(END, all_customers_list[-1])


def add_new_customer_btn():
    user_name = customer_name.get()
    user_surname = customer_surname.get()
    user_age = customer_age.get()
    user_phone = customer_phone.get()
    # for elem in all_customers_list:

    if user_name !='' and user_surname !='' and user_age !='' and user_phone !='':
        add_new_customers(user_name, user_surname, user_age, user_phone)

    else:
        messagebox.showwarning('Xeta','Xanalari doldurun')

# def add_new_product_button():
#     product_name = p_entry.get()
#     product_count = p_count_entry.get()
#     product_price = p_price_entry.get()
#     add_new_product(product_name,product_price,product_count)

def del_person_btn_func():
    if len(person_list_box.curselection())>0:
        choice_indeks = person_list_box.curselection()[0]
        person_list_box.delete(choice_indeks)
        all_customers_list.pop(choice_indeks)


def del_product_btn_func():
    if len(product_list_box.curselection())>0:
        choice_indeks = product_list_box.curselection()[0]
        product_list_box.delete(choice_indeks)
        all_product_list.pop(choice_indeks)


def sh0w_info_btn_btn():
    # if len(person_list_box.curselection())>0:
        choice_indeks = person_list_box.curselection()[0]
        temp_show_info_frame = Frame(width=800,height=1000,bg='white')
        temp_show_info_frame.place(x=120,y=50)
        temp_lbl_info = Label(temp_show_info_frame,text=all_customers_list[choice_indeks])
        temp_lbl_info.place(x=20,y=20)
        temp_person_bought_product_listbox = Listbox(temp_show_info_frame,width=60)
        temp_person_bought_product_listbox.place(x=10,y=100)
        for elem in all_customers_list[choice_indeks].bought_list:
            temp_person_bought_product_listbox.insert(END,elem)

        def close_info_frame():
            temp_show_info_frame.destroy()

        close_btn = Button(temp_show_info_frame,text='X',command=close_info_frame)
        close_btn.place(x=750,y=10)



def sh0w_info_product_btn():
    # if len(person_list_box.curselection())>0:
        choice_indeks = product_list_box.curselection()[0]
        temp_show_info_frame = Frame(width=400,height=1000,bg='white')
        temp_show_info_frame.place(x=120,y=50)
        temp_lbl_info = Label(temp_show_info_frame,text=all_product_list[choice_indeks])
        temp_lbl_info.place(x=20,y=20)
        # temp_product_bought_product_listbox = Listbox(temp_show_info_frame,width=60)
        # temp_product_bought_product_listbox.place(x=10,y=100)
        # for elem in all_customers_list[choice_indeks].bought_list:
        #     temp_person_bought_product_listbox.insert(END,elem)

        def close_info_frame():
            temp_show_info_frame.destroy()

        close_btn = Button(temp_show_info_frame,text='X',command=close_info_frame)
        close_btn.place(x=350,y=10)


def Refresh_person_btn():
    person_list_box.delete(0,END)

def Refresh_product_btn():
    product_list_box.delete(0,END)

def find_product_indeks(name):
    indeks = 0
    for elem in all_product_list:
        if elem.name_product == name:
            return indeks

        indeks += 1
    else:
        return -1


def find_customer_indeks(name):
    indeks = 0
    for elem in all_customers_list:
        if elem.name == name:
            return indeks
        indeks += 1
    else:
        return -1


def buy_product(cust_object, prod_object):
    cust_object.bought_list.append(prod_object)
    all_product_list.remove(prod_object)



# def make_sell_sell_btn():
#     user_name = ms_cust_object_entry.get()
#     product_name = ms_product_object_entry.get()
#     product_price = ms_sell_price_entry.get()
#     buy_product(user_name,product_name)
#     total_money.append(int(product_price))







wind = Tk()

# window(1000x700)
wind.title('MY proggam with pages')
wind.geometry('1000x700')
wind.resizable(False,False)

icon_cust = PhotoImage(file='image/customer-icon-2.jpg-2.png')
btn_customers = Button(text='Customers',command=customers_frame,image=icon_cust)
btn_customers.place(x=5,y=10)

icon_prod = PhotoImage(file='image/4129437-2.png')
btn_products = Button(text='Products',command=Products_frame,image=icon_prod)
btn_products.place(x=5,y=90)

icon_make_sell = PhotoImage(file='image/sell-selling-icon.png')
btn_MakeSell = Button(text='Make Sell',command=MakeSell_frame,image=icon_make_sell)
btn_MakeSell.place(x=5,y=170)

icon_calc = PhotoImage(file='image/1176289-2.png')
btn_info = Button(text=' Calc.',command=Info_frame,image=icon_calc)
btn_info.place(x=5,y=250)


#---------------frames------------------------

frameProducts =  Frame(bg='grey', width=900, height=700)
frameProducts.place(x=110, y=10)

frameMakeSell = Frame(bg='grey',width=900,height=700)
frameMakeSell.place(x=110,y=10)

frameInfo = Frame(bg='grey', width=900, height=700)
frameInfo.place(x=110,y=10)

frameCustomer = Frame(bg='grey', width=900, height=700)
frameCustomer.place(x=110, y=10)


#-----------------------Label and Entry--------------------
my_image1 = PhotoImage(file='image/ezgif.com-gif-maker.gif')
photo_labe = Label(frameCustomer,image=my_image1)
photo_labe.place(x=0,y=0)
customer_name_lbl = Label(frameCustomer, text='Name:  ')
customer_name_lbl.place(x=50,y=10)

customer_name = Entry(frameCustomer)
customer_name.place(x=105,y=10)

customer_surname_lbl = Label(frameCustomer, text='Surname:')
customer_surname_lbl.place(x=40,y=30)

customer_surname = Entry(frameCustomer)
customer_surname.place(x=105,y=30)


customer_age_lbl = Label(frameCustomer, text='Age:')
customer_age_lbl.place(x=395,y=10)

customer_age = Entry(frameCustomer)
customer_age.place(x=427,y=10)


customer_phone_lbl = Label(frameCustomer, text='Phone:')
customer_phone_lbl.place(x=380,y=30)

customer_phone = Entry(frameCustomer)
customer_phone.place(x=427,y=30)

#_-_-_-_-_-_-frame first buttons and Listbox_-_-_-_-_-_-

add_customer_btn = Button(frameCustomer, text='Add Customer', bg='blue',command=add_new_customer_btn)
add_customer_btn.place(x=240,y=120)


find_customer_btn = Button(frameCustomer, text='Find Customer', bg='green')
find_customer_btn.place(x=390,y=120)

person_list_box = Listbox(frameCustomer, width=85, height=12)
person_list_box.place(x=28,y=260)

refressh_icon = PhotoImage(file='image/pngfind.com-refresh-icon-png-transparent-4296335-2.png')
refresh_btn = Button(frameCustomer, text='Refresh',command=Refresh_person_btn,image=refressh_icon)
refresh_btn.place(x=28,y=470)

info_icon = PhotoImage(file='image/free-information-icon-348-thumb-2.png')
show_info_btn = Button(frameCustomer, text='Show info',command=sh0w_info_btn_btn,image=info_icon)
show_info_btn.place(x=580,y=470)

delete_icon = PhotoImage(file='image/1345874-2.png')
Delete_person_btn = Button(frameCustomer, text='Delete Person',command=del_person_btn_func,image=delete_icon)
Delete_person_btn.place(x=693,y=470)


#-------------------------------------Frame products------------------------
photo = PhotoImage(file='image/Fari_Hara_Weddings_Gray_Suit-8-900x700.png')

photo_label = Label(frameProducts,image=photo)
photo_label.place(x=0,y=0)



p_name_lbl = Label(frameProducts,text='Product Name:')
p_name_lbl.place(x=90,y=20)
p_entry = Entry(frameProducts)
p_entry.place(x=188,y=20)

p_count_lbl = Label(frameProducts,text='Product Count:')
p_count_lbl.place(x=410,y=20)
p_count_entry = Entry(frameProducts)
p_count_entry.place(x=510,y=20)


p_price_lbl = Label(frameProducts,text='Product Price $ :')
p_price_lbl.place(x=250,y=60)
p_price_entry = Entry(frameProducts)
p_price_entry.place(x=360,y=60)

add_products_btn = Button(frameProducts,text='Add Prdocucts',bg='green',command=add_new_product_btn)
add_products_btn.place(x=240,y=100)

find_products_btn = Button(frameProducts,text='Find Products',bg='blue')
find_products_btn.place(x=390,y=100)

product_list_box = Listbox(frameProducts, width=85, height=12)
product_list_box.place(x=78,y=250)

p_refresh_btn = Button(frameProducts, text='Refresh',command=Refresh_product_btn,image=refressh_icon)
p_refresh_btn.place(x=78,y=460)


p_show_info_btn = Button(frameProducts, text='Show info',command=sh0w_info_product_btn,image=info_icon)
p_show_info_btn.place(x=620,y=460)


p_Delete_product_btn = Button(frameProducts, text='Delete Product',command=del_product_btn_func,image=delete_icon)
p_Delete_product_btn.place(x=743, y=460)

#--------------Frame make sell---------------

photo_1 = PhotoImage(file='image/warm-neutral-linen-suit-mens-casual-wedding-attire.jpg.png')
photo_label_1 = Label(frameMakeSell,image=photo_1)
photo_label_1.place(x=0,y=0)

# ms_cust_object_lbl = Label(frameMakeSell,text='Customer Name:',bg='grey')
# ms_cust_object_lbl.place(x=0,y=10)
# ms_cust_object_entry = Entry(frameMakeSell)
# ms_cust_object_entry.place(x=115,y=10)

# ms_product_object_lbl = Label(frameMakeSell,text='Product Name:',bg='grey')
# ms_product_object_lbl.place(x=372,y=10)
# ms_product_object_entry = Entry(frameMakeSell)
# ms_product_object_entry.place(x=472,y=10)
#
# ms_sell_price_lbl = Label(frameMakeSell,text='Sell Price:',bg='grey')
# ms_sell_price_lbl.place(x=200,y=57)
#
# ms_sell_price_entry = Entry(frameMakeSell)
# ms_sell_price_entry.place(x=270,y=57)
def choice_person_btn_fuinc():
    global person_choice_index
    person_choice_index = person_list_box_customer.curselection()[0]

    choose_person_lbl.config(text=person_choice_index)

def choice_product_btn_fuinc():
    global product_choice_index
    product_choice_index = product_list_box_product.curselection()[0]
    choose_product_lbl.config(text=product_choice_index)

def make_sell_btn_func():
    if product_choice_index != None and person_choice_index != None:
        all_customers_list[person_choice_index].bought_list.append(all_product_list[product_choice_index])
    else:messagebox.showwarning('Warnings','Mehsulu veya musterini sedcmemisiz')




choose_person_btn = Button(frameMakeSell,text='Choose Person',width=15,command=choice_person_btn_fuinc)
choose_person_btn.place(x=55,y=220)

choose_person_lbl = Label(frameMakeSell,text='none')
choose_person_lbl.place(x=105,y=250)

choose_product_btn = Button(frameMakeSell,text='Choose Product',width=15,command=choice_product_btn_fuinc)
choose_product_btn.place(x=55,y=510)

choose_product_lbl = Label(frameMakeSell,text='none')
choose_product_lbl.place(x=105,y=540)


icon_sell = PhotoImage(file='image/images-2-2.png')
ms_sell_btn = Button(frameMakeSell,text='Sell',command=make_sell_btn_func,image=icon_sell)
ms_sell_btn.place(x=390,y=585,width=120)
# ms_re_product_btn = Button(frameMakeSell,text='Returned Product')
# ms_re_product_btn.place(x=300,y=300)

person_list_box_customer = Listbox(frameMakeSell, width=85, height=12)
person_list_box_customer.place(x=55,y=10)
product_list_box_product = Listbox(frameMakeSell, width=85, height=12)

product_list_box_product.place(x=55,y=300)
person_choice_index = None

product_choice_index = None








#----------------Frame Info------------------------
# info_about_store_lbl = Label(frameInfo,text='About store: Lorem ipsum dolor sit amet, consectetur adipiscing elit.',font="Times 20 italic bold")
# info_about_store_lbl.place(x=5,y=5)
#
# adress_lbl = Label(frameInfo,text='Adress:rhoncus mattis rhoncus urna neque viverra justo nec ultrices dui sapien eget mi proin sed',font="Times 20 italic bold")
# adress_lbl.place(x=5,y=50)
#
#
# gnrl_sale_btn = Button(frameInfo,text='General Sale')
# gnrl_sale_btn.place(x=5,y=120)
#
# general_sale_lbl = Label(frameInfo,text='Total:')
# general_sale_lbl.place(x=130,y=125)
photo_2 = PhotoImage(file='image/284-2844302_image-png-transparent-images-transparent-background-calculator-clipart-2.png')
photo_label_2 = Label(frameInfo,image=photo_2)
photo_label_2.place(x=0,y=0)

daily_price_calcul_lbl = Label(frameInfo,text='Day trading: ')
daily_price_calcul_lbl.place(x=5,y=7)
daily_price_calcul_entry = Entry(frameInfo)
daily_price_calcul_entry.place(x=105,y=5)

date_entry_lbl = Label(frameInfo,text='Date: ')
date_entry_lbl.place(x=330,y=7)

date_entry = Entry(frameInfo)
date_entry.place(x=380,y=5)

add_new_trade_button = Button(frameInfo,text='Add',command=add_new_trade_btn)
add_new_trade_button.place(x=620,y=5)


trade_list_box = Listbox(frameInfo, width=85, height=12)
trade_list_box.place(x=28,y=260)




total_lbl = Label(frameInfo,text='Total: ')
total_lbl.place(x=5,y=50)
total_money_lbl = Label(frameInfo,text='0 ')
total_money_lbl.place(x=70,y=50)







wind.mainloop()


#----------BACKEND---------------

















# btn_frame1 = Button(text='text1')
# btn_frame1.place(x=300,y=300)
# btn_frame2 = Button(text='text2')
# btn_frame2.place(x=600,y=400)
#
#
# frame2 = Frame(bg='brown',width=100,height=100)
# frame2.place(x=200,y=200)